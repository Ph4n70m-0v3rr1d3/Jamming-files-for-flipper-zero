# Flipper Zero's Sub-GHz Jamming

## Description
Looking for those jamming files that were removed from custom firmwares? Here they are. Only for educational purposes, of course.

## Usage
Add these files to `/subghz/` on your Flipper Zero (preferrably in a new directory named "Jamming"), and access them using the Sub-GHz application.

Sick video demo: https://youtu.be/aHXx3niWDnY

Complete guide: https://thecomputernoob.com/flipper-zero-jamming

## Disclaimer
* If you do not know what you are doing with these files, you should probably not try
* These files were uploaded for the purposes of education, research, and experimentation with devices you yourself own. I neither endorse nor shall be held responsible for any potentially unethical or malicious activity from *your* usage of these files
